-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 21, 2021 at 08:53 AM
-- Server version: 10.4.19-MariaDB
-- PHP Version: 8.0.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `login`
--

-- --------------------------------------------------------

--
-- Table structure for table `donasi`
--

CREATE TABLE `donasi` (
  `admin` varchar(255) NOT NULL,
  `nama` varchar(25) NOT NULL,
  `deskripsi` mediumtext DEFAULT NULL,
  `foto` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `donasi`
--

INSERT INTO `donasi` (`admin`, `nama`, `deskripsi`, `foto`) VALUES
('jarwo', 'CYLINDER BLOK XTR 62 MM ', 'Rp. 1.450.000', 'block.jpg'),
('jayus', 'KALIPER NISSIN SAMURAI ', 'Rp. 750.000', 'nissin.jpg'),
('jek ', 'ARM B-PRO SUPRA', 'Rp. 625.000', 'arm.jpg'),
('joker ', 'PER KLEP MOTO 1', 'Rp. 150.000', 'mio.jpg'),
('kepo', 'HANDLE KOPLING R25', 'Rp. 150.000', 'r25.jpg'),
('sapu jagat', 'PIRINGAN TDR', 'Rp. 500.000', 'tdr.jpg'),
('zulfikar', 'Noken as BRT honda grand,', 'Rp. 500.000', 'noken as.jpg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `donasi`
--
ALTER TABLE `donasi`
  ADD PRIMARY KEY (`admin`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
